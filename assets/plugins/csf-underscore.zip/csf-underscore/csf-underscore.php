<?php
/*
Plugin Name: Codestar Framework Underscore
Plugin URI: http://codestarframework.com/
Description: Create your underscores based framework
Author: Codestar
Version: 1.0.1
Author URI: http://codestarthemes.com/
*/

/**
 * Main class.
 */
if( ! class_exists( 'CSF_Underscore' ) ) {
  class CSF_Underscore {

    public $upload_dir;
    public $temp_dir;
    public $main_zip;
    public $source;
    public $prefix;
    public $exclude;
    public $wpnonce;
    public $filesystem;
    public static $instance;

    public static function instance() {
      if( ! isset( self::$instance ) && !( self::$instance instanceof self ) ) {
        self::$instance = new self();
      }
      return self::$instance;
    }

    public function __construct() {
      add_action( 'admin_init', array( $this, 'admin_init' ) );
      add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
      add_action( 'admin_head', array( $this, 'add_admin_style' ) );
    }

    public function add_admin_menu() {
      add_menu_page( 'CSF Underscore', 'CSF Underscore', 'manage_options', 'underscores', array( $this, 'add_admin_page_contents' ), 'dashicons-update' );
    }

    public function add_admin_style() {
    ?>
      <style type="text/css">
        .csf-underscore-wrap{
          margin-top: 20px;
          max-width: 850px;
          font-size: 13px;
          line-height: 1.7;
          background-color: #fff;
          border: 1px solid #ccd0d4;
          box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .csf-underscore-header{
          padding: 15px;
          background-color: #f7f7f7;
          border-bottom: 1px solid #ccd0d4;
        }
        .csf-underscore-header h1{
          margin: 0;
          padding: 0;
        }
        .csf-underscore-header span{
          color: #999;
        }
        .csf-underscore-step{
          padding: 15px;
          border-bottom: 1px solid #eee;
        }
        .csf-underscore-step:last-child{
          border-bottom: none;
        }
        .csf-underscore-step ul{
          display: inline-block;
          margin: 0;
          padding: 0;
        }
        .csf-underscore-step ul li:last-child{
          margin: 0;
        }
        .csf-underscore-number{
          display: inline-block;
          margin-right: 10px;
          font-size: 13px;
          font-weight: bold;
          line-height: 1em;
          margin-top: 6px;
          vertical-align: top;
        }
        .csf-underscore-sensible{
          color: #999;
        }
        .csf-underscore-file{
          display: none;
          margin-top: 10px;
        }
        .csf-underscore-premium:checked + .csf-underscore-file{
          display: block;
        }
        .csf-underscore-footer{
          padding: 15px;
          border-top: 1px solid #ccd0d4;
          background-color: #f7f7f7;
        }
        .csf-underscore-error{
          color: #a00;
          margin-left: 25px;
          margin-top: 10px;
        }
      </style>
    <?php
    }

    public function add_admin_page_contents() {
    ?>
      <div class="wrap">
        <form action="" method="POST" enctype="multipart/form-data">
          <?php wp_nonce_field( 'csf-underscores', '_wp_nonce' ); ?>
          <div class="csf-underscore-wrap">
            <div class="csf-underscore-header">
              <h1>Codestar Framework</h1>
              <span>Create your underscores based framework</span>
            </div>
            <div class="csf-underscore-content">
              <div class="csf-underscore-step">
                <span class="csf-underscore-number">1.</span>
                <ul>
                  <li><label><input type="radio" name="source" value="free" checked /> Free Version (Github Repo)</label></li>
                  <li>
                    <label>
                      <input type="radio" name="source" value="premium" class="csf-underscore-premium" /> Premium Version (Self Upload)
                      <div class="csf-underscore-file"><input type="file" name="self" accept=".zip,application/zip" /></div>
                    </label>
                  </li>
                </ul>
              </div>  
              <div class="csf-underscore-step">
                <span class="csf-underscore-number">2.</span>
                <input type="text" name="prefix" placeholder="prefix" value="" autocomplete="off" />
                <span class="csf-underscore-sensible">Please typing a sensible prefix. for eg. (<i>deepocean, piranha, magnet, soundex, strx, something</i>)</span>
                <?php if( ! empty( $_POST['source'] ) && empty( $_POST['prefix'] ) ) { ?><div class="csf-underscore-error">Please type a prefix.</div><?php } ?>
              </div>  
              <div class="csf-underscore-step">
                <span class="csf-underscore-number">3.</span>
                <label><input type="checkbox" name="exclude" value="true" />Exclude unnecessary files. (views, samples, README.md, LICENSE.md)</label>
              </div>  
            </div>
            <div class="csf-underscore-footer">
              <button class="button button-primary">Generate</button>
            </div>
          </div>
        </form>
      </div>
    <?php
    }

    public function admin_init() {

      $this->prefix  = ( ! empty( $_POST['prefix'] ) ) ? sanitize_text_field( $_POST['prefix'] ) : '';
      $this->source  = ( ! empty( $_POST['source'] ) ) ? sanitize_text_field( $_POST['source'] ) : '';
      $this->exclude = ( ! empty( $_POST['exclude'] ) ) ? sanitize_text_field( $_POST['exclude'] ) : '';
      $this->wpnonce = ( ! empty( $_POST['_wp_nonce'] ) ) ? sanitize_text_field( $_POST['_wp_nonce'] ) : '';

      if( ! empty( $this->prefix ) ) {

        $this->prefix = str_replace( '-', '_', sanitize_title( preg_replace( '/[0-9]/', '', $this->prefix ) ) );

        try{

          if( empty( $this->prefix ) ) {
            throw new Exception( 'Please type a sensible prefix.' );
          }

          if( ! wp_verify_nonce( $this->wpnonce, 'csf-underscores' ) ) {
            throw new Exception( 'Security issue.' );
          }

          @set_time_limit(0);
          
          $this->filesystem = $this->get_filesystem();
          $this->upload_dir = wp_upload_dir();
          $this->temp_dir   = $this->upload_dir['basedir'] .'/csf-tmp/';
          $this->temp_zip   = $this->upload_dir['basedir'] .'/csf-tmp/'. $this->prefix .'-framework.zip';
          $this->main_zip   = $this->upload_dir['basedir'] .'/csf-tmp/codestar-framework.zip';

          if( ! $this->filesystem->exists( $this->temp_dir ) ) {
            if( ! $this->filesystem->mkdir( $this->temp_dir ) ) {
              throw new Exception( 'Temp directory could not created.' );
            }
            if( ! $this->filesystem->is_writable( $this->temp_dir ) ) {
              throw new Exception( 'Temp directory is not writable.' );
            }
          }

          if( $this->source === 'premium' ) {

            if( ! empty( $_FILES['self'] ) && ! empty( $_FILES['self']['name'] ) && $_FILES['self']['type'] === 'application/zip' ) {
              if( ! move_uploaded_file( $_FILES['self']['tmp_name'], $this->main_zip ) ) {
                throw new Exception( 'File could not uploaded.' );
              }
            } else {
              throw new Exception( 'Please upload the zip file.' );
            }

          } else {

            $download_github_repo = wp_remote_get( 'https://github.com/Codestar/codestar-framework/archive/master.zip', array( 'timeout' => 360 ) );

            if( is_wp_error( $download_github_repo ) || wp_remote_retrieve_response_code( $download_github_repo ) !== 200 ) {
              throw new Exception( 'Github zip file could not downloaded.' );
            }

            $download_github_repo_body = wp_remote_retrieve_body( $download_github_repo );

            if( ! $this->filesystem->put_contents( $this->main_zip, $download_github_repo_body ) ) {
              throw new Exception( 'Github zip file could not written.' );
            }

          }

          $unzip = unzip_file( $this->main_zip, $this->temp_dir );

          if( is_wp_error( $unzip ) ) {
            throw new Exception( 'Zip file could not unziped.' );
          }

          if ( ! class_exists( 'PclZip' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
          }

          $zip_obj       = new PclZip( $this->temp_zip );
          $zip_root      = ( $this->source === 'premium' ) ? 'codestar-framework/' : 'codestar-framework-master/';
          $exclude_files = array( '.', '..' );
          $exclude_dirs  = array( '.', '..' );

          if( ! empty( $this->exclude ) ) { 
            array_push( $exclude_files, 'README.md', 'LICENSE.md', 'wp-logo.svg', 'wp-plugin-logo.svg' );
            array_push( $exclude_dirs, 'views', 'samples' );
          }

          $iterator = new RecursiveDirectoryIterator( $this->temp_dir . $zip_root );

          foreach ( new RecursiveIteratorIterator( $iterator ) as $filename ) {

            if ( in_array( basename( $filename ), $exclude_files ) ) {
              continue;
            }

            foreach ( $exclude_dirs as $dir ) {
              if ( strstr( $filename, "/{$dir}/" ) ) {
                continue 2;
              }
            }

            $localname = str_replace( $this->temp_dir . $zip_root, $this->prefix .'-framework/', $filename );
            $contents  = file_get_contents( $filename );

            if ( preg_match( "/\.(php|css|scss|js|po|pot)$/", $localname ) ) {

              $contents = str_replace( 'CODESTAR', strtoupper( $this->prefix ), $contents );
              $contents = str_replace( 'Codestar', ucfirst( $this->prefix ), $contents );
              $contents = str_replace( 'codestar', $this->prefix, $contents );
              $contents = str_replace( 'csf', $this->prefix, $contents );
              $contents = str_replace( 'CSF', strtoupper( $this->prefix ), $contents );
              $contents = str_replace( 'codestar-framework/codestar-framework.php', $this->prefix .'-framework/'. $this->prefix .'-framework.php', $contents );

            }

            if ( basename( $filename ) === 'codestar-framework.php' ) {

              $newname = dirname( $localname ) .'/'. $this->prefix .'-framework.php';

              $zip_obj->add( array( array( PCLZIP_ATT_FILE_NAME => $newname, PCLZIP_ATT_FILE_CONTENT => $contents ) ) );
            
            } else {

              $zip_obj->add( array( array( PCLZIP_ATT_FILE_NAME => $localname, PCLZIP_ATT_FILE_CONTENT => $contents ) ) );

            }

          }

          header( 'Content-type: application/zip' );
          header( 'Content-Disposition: attachment; filename="'. $this->prefix .'-framework.zip"' );
          readfile( $this->temp_zip );

          $this->filesystem->rmdir( $this->temp_dir, true );

          exit;

        } catch( Exception $e ) {

          $this->message( $e->getMessage() );

        }
        
      }
    
    }

    public function get_filesystem() {

      global $wp_filesystem;

      if( ! $wp_filesystem || $wp_filesystem->method !== 'direct' ) {
        if( ! function_exists( 'WP_Filesystem' ) ) {
          require_once ABSPATH .'wp-admin/includes/file.php';
        }
        add_filter( 'filesystem_method', array( $this, 'filesystem_method_direct' ) );
        if( ! WP_Filesystem() ) {
          throw new Exception( 'Unable to connect to the filesystem. Please set "direct" filesystem method.' );
        }
        remove_filter( 'filesystem_method', array( $this, 'filesystem_method_direct' ) );
      }

      return $wp_filesystem;

    }

    public function filesystem_method_direct() {
      return 'direct';
    }

    public function message( $text ) {
      wp_die( $text . sprintf( '<br /><a href="%s">Go back</a></p>', add_query_arg( array( 'page' => 'underscores' ), admin_url( 'admin.php' ) ) ) );
    }

  }
  CSF_Underscore::instance();
}